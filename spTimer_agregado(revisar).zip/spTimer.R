## 1. Preparación del entorno de trabajo

# Carga de spTimer
if (!require((spTimer))){
  install.packages("spTimer")
  library(spTimer)
}

# Carga de dplyr
if (!require((dplyr))){
  install.packages("dplyr")
  library(dplyr)
}

# Carga de dplyr
if (!require((lubridate))){
  install.packages("lubridate")
  library(lubridate)
}

# Verificacion librerias cargadas
(.packages())

# Directorio de trabajo
setwd("C:/Users/Emi/Desktop/UAH-TFM-master/data")

## 2. Preprocesado

df <- read.table("EK1001.csv", sep=",", header=T)

time.data<-spT.time(t.series=90,segment=1)

df$element_key <- NULL
df$mes <- NULL
df$X <- NULL
levels(df$franja) <- c(1,2,3)
df$franja <- as.integer(df$franja)
df$s.index <- 1
df <- df[c("s.index", "longitude", "latitude", "dia", "franja", "occupation_perc", "prcp", "tmax", "tmin")]
df$dia <- NULLD
df$franja <- NULL

post.gp <- spT.Gibbs(formula=occupation_perc ~ prcp + tmax + tmin,
                     data=df, 
                     model="GP", 
                     coords=~longitude+latitude,
                     time.data=time.data,
                     distance.method="geodetic:km", 
                     scale.transform="SQRT",
                     spatial.decay=spT.decay(distribution=Gamm(2,1),tuning=0.1))
